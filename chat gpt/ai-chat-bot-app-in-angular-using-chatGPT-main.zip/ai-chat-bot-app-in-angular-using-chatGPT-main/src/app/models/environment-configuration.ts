export interface EnvironmentConfiguration {
    env_name: string;
    production: boolean;    
    apiKey:string;
}